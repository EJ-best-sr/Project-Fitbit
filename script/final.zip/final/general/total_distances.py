import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import streamlit as st

# def plot_distances(df):
#     total_distance_per_user = df.groupby('Id')['TotalDistance'].sum().reset_index()
    
#     fig, ax = plt.subplots(figsize=(10, 6))
#     sns.barplot(x='Id', y='TotalDistance', data=total_distance_per_user, ax=ax)
#     ax.set_xlabel('User ID')
#     ax.set_ylabel('Total Distance')
    
#     return fig

def plot_distances(df):
    total_distance_per_user = df.groupby('Id')['TotalDistance'].sum().reset_index()
    
    fig, ax = plt.subplots(figsize=(10, 6))
    sns.barplot(x='Id', y='TotalDistance', data=total_distance_per_user, ax=ax)
    ax.set_xticks([])
    ax.set_xlabel('Users')
    
    ax.set_ylabel('Total Distance')
    plt.tight_layout()
    
    return fig

# def plot_distances(df):
#     total_distance_per_user = df.groupby('Id')['TotalDistance'].sum().reset_index()
    
#     # Create an interactive bar plot using Plotly
#     fig = px.bar(
#         total_distance_per_user, 
#         x='Id', 
#         y='TotalDistance', 
#         labels={'TotalDistance': 'Total Distance'},
#         width=800  # Set the width of the chart
#     )
    
#     # Adjust bar width
#     fig.update_traces(width=100)  # Set bar width (0.5 is a good starting point)
#     fig.update_xaxes(showticklabels=False, title_text='')
    
#     return fig

