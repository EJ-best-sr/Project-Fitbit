import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import seaborn as sns
import sys, os

module_dir = '/Users/kseniapiven/DEpython/fitbit' #this should be a directory where daily_acivity.csv is
sys.path.append(module_dir)

from load_data import load_data
from general.total_distances import plot_distances


st.set_page_config(layout="wide")

# CSS
st.markdown(
    """
    <style>
    .stButton > button {
        width: 100%;
        border-radius: 10px;
        border: 2px solid black;
        background-color: white;
        color: black;
        padding: 10px 24px;
        cursor: pointer;
        float: left;
    }
    .stButton > button:hover {
    color: #1588ed;
    border: 2px solid #1588ed;
    }
    .stButton > button:active {
    background-color: white;
    color: #1588ed;
    border: 2px solid #1588ed; 
    }
    .stColumns > div {
        flex: 1;
    }
    .stColumns > div:first-child {
        flex: 0.4;  /* Make the first column smaller */
    }
    .stColumns > div:nth-child(2) {
        flex: 2;  /* Make the second column wider */
    }
    .stColumns > div:last-child {
        flex: 2;  /* Make the third column wider */
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialize session state for page navigation
if "page" not in st.session_state:
    st.session_state.page = "General"

# Navigation buttons
col1, col2 = st.columns(2)
with col1:
    if st.button("General Information"):
        st.session_state.page = "General"
with col2:
    if st.button("User-Specific Analysis"):
        st.session_state.page = "User"

# Load the dataframes here
data = load_data('/Users/kseniapiven/DEpython/fitbit/daily_acivity.csv')

# Page 1: General Information
if st.session_state.page == "General":
    st.title("Fitbit Data Analytics")

    # Display general statistics   
    st.subheader("Overall Statistics")
    col1, col2, col3 = st.columns([1, 2, 2]) 

    with col1:
        st.metric("Total users", f"{data['Id'].nunique()}")
        st.metric("Mean Distance", f"{data['TotalDistance'].mean():.2f} km")
        st.metric("Median Distance", f"{data['TotalDistance'].median():.2f} km")
        st.metric("Mean Calories", f"{data['Calories'].mean():.0f} kcal")
        st.metric("Median Calories", f"{data['Calories'].median():.0f} kcal")

    with col2:
        st.subheader("Total Distances per User")
        fig1 = plot_distances(data)
        st.pyplot(fig1)
    
    st.subheader("Sample Data")
    st.dataframe(data.head())



# Page 2: User-Specific Analysis
elif st.session_state.page == "User":
    st.title("User-Specific Analysis")
    
    # Sidebar for user selection
    st.sidebar.header("User Selection")
    unique_users = data['Id'].unique().tolist()
    selected_user = st.sidebar.selectbox("Select a User", unique_users)
    
    # Filter data for the selected user
    user_data = data[data['Id'] == selected_user]
    
    # Display user-specific information
    st.subheader(f"Analysis for User: {selected_user}")
    
    col1, col2, col3 = st.columns([1, 2, 2])  # Adjust column widths
    with col1:
        st.subheader("Summary Metrics")
        st.metric("Mean Distance", f"{user_data['TotalDistance'].mean():.2f} km")
        st.metric("Median Distance", f"{user_data['TotalDistance'].median():.2f} km")
        st.metric("Mean Calories", f"{user_data['Calories'].mean():.0f} kcal")
        st.metric("Median Calories", f"{user_data['Calories'].median():.0f} kcal")
    
    with col2:
        st.subheader("Calories per Day")
        st.line_chart(user_data.set_index('ActivityDate')['Calories'])

    with col3:
        st.subheader("Total Distance per Day")
        st.bar_chart(user_data.set_index('ActivityDate')['TotalDistance'])

