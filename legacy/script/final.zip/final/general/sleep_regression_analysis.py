import plotly.graph_objects as go
import plotly.express as px
import statsmodels.api as sm
import scipy.stats as stats

def perform_regression_analysis(df_merged):
    """
    Perform regression analysis on the merged DataFrame and return Plotly figures.

    Args:
        df_merged (pd.DataFrame): The merged DataFrame containing sleep and activity data.

    Returns:
        tuple: A tuple containing three Plotly figures:
            - Regression plot
            - Histogram of residuals
            - Q-Q plot of residuals
    """
    # Remove the sleep of less than 3 hours
    df_merged_filtered = df_merged[df_merged['TotalSleepDuration'] >= 180]

    X = df_merged_filtered['TotalSedentaryMinutes']  # Independent variable
    y = df_merged_filtered['TotalSleepDuration']  # Dependent variable

    # Add a constant to the independent variable
    X = sm.add_constant(X)

    # Fit the OLS model
    model = sm.OLS(y, X).fit()
    print(model.summary())

    # Calculate predicted values and residuals
    predicted = model.predict(X)
    residuals = model.resid

    # Create the regression plot
    regression_fig = go.Figure()

    # Add scatter plot for the data points
    regression_fig.add_trace(
        go.Scatter(
            x=df_merged_filtered['TotalSedentaryMinutes'],
            y=df_merged_filtered['TotalSleepDuration'],
            mode='markers',
            #marker=dict(color='rgba(74, 55, 111, 0.8)'),  # Custom marker color
            name='Data Points'
        )
    )

    # Add regression line
    regression_fig.add_trace(
        go.Scatter(
            x=df_merged_filtered['TotalSedentaryMinutes'],
            y=predicted,
            mode='lines',
            line=dict(color='rgba(0, 0, 0)'),  # Custom line color
            name='Regression Line'
        )
    )

    # Update layout for the regression plot
    regression_fig.update_layout(
        title='Regression: Sedentary Time vs Sleep Time',
        xaxis_title='Total Sedentary Minutes',
        yaxis_title='Total Sleep Duration',
        showlegend=True,
        template='plotly_white',
        width=800,  
        height=400, 
        margin=dict(l=0, r=0, t=50, b=0),
        autosize=False, 
        legend=dict(
            x=0.02,  
            y=0.98, 
            xanchor='left',
            yanchor='top', 
            bgcolor='rgba(255, 255, 255, 0.5)',
            bordercolor='rgba(0, 0, 0, 0.5)',
            borderwidth=1 
        )
    )

    # Create the histogram of residuals
    residuals_histogram = px.histogram(
        x=residuals,
        nbins=30,
        labels={'x': 'Residuals', 'y': 'Frequency'},
        title='Histogram of Residuals',
        color_discrete_sequence=['rgba(69, 86, 128, 0.8)']  # Custom color
    )

    # Update layout for the histogram
    residuals_histogram.update_layout(
        template='plotly_white',
        width=800,  
        height=400, 
        margin=dict(l=0, r=0, t=50, b=0),
        autosize=False, 
    )

    # Create the Q-Q plot
    qq_fig = go.Figure()

    # Calculate theoretical quantiles and sample quantiles
    # theoretical_quantiles = stats.probplot(residuals, dist="norm")[0][0]
    # sample_quantiles = stats.probplot(residuals, dist="norm")[0][1]
    (theoretical_quantiles, sample_quantiles), (slope, intercept, _) = stats.probplot(residuals, dist="norm")    
    # Add scatter plot for the Q-Q points
    qq_fig.add_trace(
        go.Scatter(
            x=theoretical_quantiles,
            y=sample_quantiles,
            mode='markers',
            marker=dict(color='rgba(69, 86, 128, 0.8)', line=dict(color='black', width=1)),
            name='Q-Q Points'
        )
    )

    # Add line for the theoretical quantiles
    # slope = float(slope)
    # intercept = float(intercept)
    #theoretical_line = slope * theoretical_quantiles + intercept
    qq_fig.add_trace(
        go.Scatter(
            x=[theoretical_quantiles.min(), theoretical_quantiles.max()],
            y=[theoretical_quantiles.min(), theoretical_quantiles.max()],
            mode='lines',
            line=dict(color='rgba(44, 131, 127, 1)', dash='dash'),
            name='Theoretical Line'
        )
    )
    # qq_fig.add_shape(
    #     type="line",
    #     x0=theoretical_quantiles.min(),
    #     y0=theoretical_quantiles.min(),
    #     x1=theoretical_quantiles.max(),
    #     y1=theoretical_quantiles.max(),
    #     line=dict(color='rgba(44, 131, 127, 1)', dash='dash'),
    #     name='Theoretical Line'
    # )

    # Update layout for the Q-Q plot
    qq_fig.update_layout(
        title='Q-Q Plot of Residuals',
        xaxis_title='Theoretical Quantiles of Normal Distribution',
        yaxis_title='Sample Quantiles',
        showlegend=True,
        template='plotly_white',
        width=800,  
        height=400,
        autosize=False, 
        margin=dict(l=0, r=0, t=50, b=0),
        legend=dict(
            x=0.02,  
            y=0.98, 
            xanchor='left',
            yanchor='top', 
            bgcolor='rgba(255, 255, 255, 0.5)',
            bordercolor='rgba(0, 0, 0, 0.5)',
            borderwidth=1 
        ) 
    )

    return regression_fig, residuals_histogram, qq_fig