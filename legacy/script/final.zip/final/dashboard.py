import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import seaborn as sns
import sys, os

# module_dir = '/Users/kseniapiven/DEpython/fitbit' #this should be a directory where daily_acivity.csv is
# sys.path.append(module_dir)
db_path = os.path.join(os.path.dirname(__file__), "..", "fitbit_database.db")
db_path = os.path.normpath(db_path)

from load_data import load_data
from general.total_distances import plot_distances
from final.sleep_vs_activity.sleep_vs_sedentary import calculate_user_statistics_sedentary, calculate_user_statistics_sleep
from final.sleep_vs_activity.sleep_vs_sedentary import load_and_process_data
from final.sleep_vs_activity.sleep_vs_sedentary import load_and_process_sleepdata
from final.user_spec.calories_steps_regression import plot_regression_line
from final.general.plot_workout_frequency_by_day import plot_workout_frequency_by_day
from final.general.sleep_regression_analysis import perform_regression_analysis
from final.general.calories_vs_steps import calories_vs_steps_regression

st.set_page_config(layout="wide")

# CSS
st.markdown(
    """
    <style>
    .stButton > button {
        width: 100%;
        border-radius: 10px;
        border: 2px solid black;
        background-color: white;
        color: black;
        padding: 10px 24px;
        cursor: pointer;
        float: left;
    }
    .stButton > button:hover {
    color: #1588ed;
    border: 2px solid #1588ed;
    }
    .stButton > button:active {
    background-color: white;
    color: #1588ed;
    border: 2px solid #1588ed; 
    }
    .stColumns > div {
        flex: 1;
    }
    .stColumns > div:first-child {
        flex: 0.4;  /* Make the first column smaller */
    }
    .stColumns > div:nth-child(2) {
        flex: 2;  /* Make the second column wider */
    }
    .stColumns > div:last-child {
        flex: 2;  /* Make the third column wider */
    }
    .block-container {
        padding-top: 5rem;
    }
    h3 {
        margin-bottom: 0px;
    }
    .element-container {
        padding-top: 0px;
        margin-top: 0px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Initialize session state for page navigation
if "page" not in st.session_state:
    st.session_state.page = "General"

# Navigation buttons
col1, col2 = st.columns(2)
with col1:
    if st.button("General Information"):
        st.session_state.page = "General"
with col2:
    if st.button("User-Specific Analysis"):
        st.session_state.page = "User"



# Load the dataframes here
data = load_data('/Users/kseniapiven/DEpython/fitbit/daily_acivity.csv')
data['ActivityDate'] = pd.to_datetime(data['ActivityDate'])
# Here we load the dataframe with merged sleep and sedentary records
df_sleep_sed = load_and_process_data(db_path)
df_sleep = load_and_process_sleepdata(db_path)


# Page 1: General Information
if st.session_state.page == "General":
    st.title("Fitbit Data Analytics")

    # Display general statistics   
    st.subheader("Overall Statistics")
    col1, col2, col3 = st.columns([1, 2, 2]) 

    with col1:
        st.metric("Total users", f"{data['Id'].nunique()}")
        st.metric("Average Distance", f"{data['TotalDistance'].mean():.2f} km")
        #st.metric("Median Distance", f"{data['TotalDistance'].median():.2f} km")
        st.metric("Average Calories", f"{data['Calories'].mean():.0f} kcal")
        #st.metric("Median Calories", f"{data['Calories'].median():.0f} kcal")
        st.metric("Average Sleep Duration", f"{calculate_user_statistics_sleep(df_sleep)} min")
        st.metric("Average Sedentary Minutes", f"{calculate_user_statistics_sedentary(df_sleep_sed)} min")


    with col2:
        #st.subheader("Total Distances per User")
        # st.write("#### Total Distance per User")
        fig1 =plot_distances(data)
        # st.plotly_chart(fig1)
        with st.container():
            st.subheader("Total Distance per User")
            st.plotly_chart(fig1, use_container_width=True)

    with col3:
        st.subheader("Workout Frequency by Day")
        fig = plot_workout_frequency_by_day(data)
        st.plotly_chart(fig)

    
    # Second block of three columns
    st.header('Sedentary Time vs Sleep Time Analysis')
    col4, col5, col6 = st.columns(3)

    regression_fig, residuals_histogram, qq_fig = perform_regression_analysis(df_sleep_sed)

    with col4:
        #st.write("Regression: Sedentary Time vs Sleep Time")
        st.plotly_chart(regression_fig)

    with col5:
        #st.write("Histogram of Residuals of the Regression")
        st.plotly_chart(residuals_histogram)

    with col6:
        #st.write("Q-Q Plot of Residuals")
        st.plotly_chart(qq_fig)


    st.subheader("Calories Burnt vs Steps")

    with st.container():
        fig = calories_vs_steps_regression(db_path)
        st.pyplot(fig)
    

    st.subheader("Sample Data")
    st.dataframe(data.head())



# Page 2: User-Specific Analysis
elif st.session_state.page == "User":
    st.title("User-Specific Analysis")
    
    # Sidebar for selecting a user
    st.sidebar.header("User Selection")
    unique_users = data['Id'].unique().tolist()
    selected_user = st.sidebar.selectbox("Select a User", unique_users)
    
    # Filter data for the selected user
    user_data = data[data['Id'] == selected_user]
    
    # Display user-specific information
    st.subheader(f"Analysis for User: {selected_user}")
    
    col1, col2, col3 = st.columns([1, 2, 2])  # Adjust column widths
    with col1:
        st.subheader("Summary Metrics")
        st.metric("Average Distance", f"{user_data['TotalDistance'].mean():.2f} km")
        #st.metric("Median Distance", f"{user_data['TotalDistance'].median():.2f} km")
        st.metric("Average Calories", f"{user_data['Calories'].mean():.0f} kcal")
        #st.metric("Median Calories", f"{user_data['Calories'].median():.0f} kcal")
        st.metric("Average Sleep Duration", f"{calculate_user_statistics_sleep(df_sleep, selected_user)} min")
        st.metric("Average Sedentary Minutes", f"{calculate_user_statistics_sedentary(df_sleep_sed, selected_user)} min")


    
    with col2:
        st.subheader("Calories per Day")
        st.line_chart(user_data.set_index('ActivityDate')['Calories'])

        st.subheader("Calories vs Steps Regression")
        fig = plot_regression_line(data, selected_user)
        st.plotly_chart(fig)



    with col3:
        st.subheader("Total Distance per Day")
        st.bar_chart(user_data.set_index('ActivityDate')['TotalDistance'])

